<?php $__env->startSection('title'); ?>
    Case Categories
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pagetitle">
        <h1>Categories</h1>
        <div class="row" class="d-flex justify-content-between">
            <div class="col-6">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item">Case</li>
                        <li class="breadcrumb-item active">Categories</li>
                    </ol>
                </nav>
            </div>
            <div class="col-6 text-end">
                <button class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#verticalycentered"> Add
                    New</button>
            </div>
        </div>

    </div><!-- End Page Title -->

    <section class="section">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">All Case Categories</h5>

                    <?php if(\Session::get('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show mt-2 mb-2" role="alert">
                            <i class="bi bi-check-circle me-1"></i>
                            <?php echo e(\Session::get('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php echo e(\Session::forget('success')); ?>

                    <?php if(\Session::get('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show mt-2 mb-2" role="alert">
                            <i class="bi bi-exclamation-octagon me-1"></i>
                            <?php echo e(\Session::get('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Default Table -->
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th scope="row"><?php echo e($data->id); ?></th>
                                    <td><?php echo e($data->name); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="" class="btn btn-secondary btn-sm"> Edit</a>
                                            &nbsp;
                                            <a href="" class="btn btn-danger btn-sm"> Delete</a>

                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan="3"> Sorry No Case Category Yet </td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                    <!-- End Default Table Example -->
                </div>
            </div>
        </div>
        
        <div class="modal fade" id="verticalycentered" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Add Case Category</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form action="<?php echo e(route('categories.save')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row form-group">
                                <div class="col-12">
                                    <label for="name"> Name: </label>
                                    <input type="text" name="name" id="name" class="form-control" required>
                                </div>


                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                    </form>
                </div>
            </div>
        </div><!-- End Vertically centered Modal-->
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/user/dev/sites/reportcase/resources/views/admin/case/categories.blade.php ENDPATH**/ ?>