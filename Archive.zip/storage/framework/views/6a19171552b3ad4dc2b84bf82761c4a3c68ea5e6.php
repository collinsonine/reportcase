<?php $__env->startSection('title'); ?>
    All Casses
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="pagetitle">
        <h1>All Cases</h1>
        <div class="row" class="d-flex justify-content-between">
            <div class="col-6">
                <nav>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
                        <li class="breadcrumb-item">Case</li>
                        <li class="breadcrumb-item active">All Cases</li>
                    </ol>
                </nav>
            </div>
            <div class="col-6 text-end">
                <a class="btn btn-primary btn-sm" href="<?php echo e(route('case.new')); ?>"> Add
                    New</a>
            </div>
        </div>

    </div><!-- End Page Title -->

    <section class="section">
        <div class="col-lg-12">

            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">All Case</h5>

                    <?php if(\Session::get('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show mt-2 mb-2" role="alert">
                            <i class="bi bi-check-circle me-1"></i>
                            <?php echo e(\Session::get('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <?php echo e(\Session::forget('success')); ?>

                    <?php if(\Session::get('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show mt-2 mb-2" role="alert">
                            <i class="bi bi-exclamation-octagon me-1"></i>
                            <?php echo e(\Session::get('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>

                    <!-- Default Table -->
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Case ID</th>
                                <th scope="col">Name</th>
                                <th scope="col">Case Title</th>
                                <th scope="col">Case Category</th>
                                <th scope="col">Image</th>
                                <th scope="col">Description</th>
                                <th scope="col">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $crime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <th scope="row"><?php echo e($data->case_id); ?></th>
                                    <td><?php echo e($data->name); ?></td>
                                    <td><?php echo e($data->title); ?></td>
                                    <td><?php echo e($data->casecategory); ?></td>
                                    <td><?php echo e($data->image); ?></td>
                                    <td><?php echo e($data->description); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(url('/admin/case/edit/'.$data->id)); ?>" class="btn btn-secondary btn-sm"> Edit</a>
                                            &nbsp;
                                            <a href="" class="btn btn-danger btn-sm"> Delete</a>

                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center" colspan="3"> Sorry No Case Category Yet </td>
                                </tr>
                            <?php endif; ?>

                        </tbody>
                    </table>
                    <!-- End Default Table Example -->
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/user/dev/sites/reportcase/resources/views/admin/case/allcase.blade.php ENDPATH**/ ?>