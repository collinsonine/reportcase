<?php $__env->startSection('title'); ?>
    Edit Case <?php echo e($crime->case_id); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="pagetitle">
    <h1>New Case</h1>
    <nav>
      <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></li>
        <li class="breadcrumb-item">Case</li>
        <li class="breadcrumb-item active">New</li>
      </ol>
    </nav>
  </div><!-- End Page Title -->

  <section class="section">
    <div class="row">
      <div class="col-lg-12">



        <div class="card">
          <div class="card-body">
            <h5 class="card-title">Edit Case</h5>
            <form class="insform" action="<?php echo e(url('/admin/case/update/'.$crime->id)); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
            <!-- Quill Editor Full -->
            <div class="row">
                <div class="col-6">
                    <div class="form-group mb-3">
                        <label for="name"> Name</label>
                        <input type="text" name="name" value="<?php echo e($crime->name); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group mb-3">
                        <label for="Case Description"> Case ID</label>
                        <input type="text" name="case_id" value="<?php echo e($crime->case_id); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-12">
                    <div class="form-group mb-3">
                        <label for="Case Description"> Case Title</label>
                        <input type="text" name="title" value="<?php echo e($crime->title); ?>" class="form-control">
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group mb-3">
                        <label for="category"> Case Category</label>
                        <select name="casecategory" id="" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($cate->name); ?>"><?php echo e($cate->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>
                    </div>
                </div>
                <div class="col-6">
                    <div class="form-group mb-3">
                        <label for="image"> Image </label>
                        <input type="file" class="form-control" name="image" id="image">
                    </div>
                </div>
            </div>
            <div class="p-4">
                <!-- The toolbar will be rendered in this container. -->
           <div id="toolbar-container"></div>
            <!-- This container will become the editable. -->
            <div id="editor" class="border">
                <?php echo $crime->description; ?>

            </div>

            </div>
            <div class="p-4">


                <input type="hidden" name="instruction" class="form-control thisist" >
                <div class="d-grid">
                   <button class="btn btn-primary thisidhvb"> Update</button>
                </div>

                </form>
            </div>

          </div>
        </div>


      </div>

    </div>
  </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/assets/js/new/ckeditor.js')); ?>"></script>
<script>
    DecoupledEditor
            .create( document.querySelector( '#editor' ) )
            .then( editor => {
                const toolbarContainer = document.querySelector( '#toolbar-container' );

                toolbarContainer.appendChild( editor.ui.view.toolbar.element );
            } )
            .catch( error => {
                console.error( error );
            } );
            $('#editor').blur(function (e) {
                e.preventDefault();
                $('.thisist').val($('#editor').html());
            });

            $('.thisidhvb').click(function (e) {
                e.preventDefault();
                $('.insform').submit();
            });
            $(document).ready(function () {
                $('.thisist').val($('#editor').html());
            });
     </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/user/dev/sites/reportcase/resources/views/admin/case/edit.blade.php ENDPATH**/ ?>